
# Server Configuration
server_url = "http://172.30.1.71:5000/agv_data"

# GPIO Pin Configuration
GPIO_DIR_PIN = 11
GPIO_STEP_PIN = 7

